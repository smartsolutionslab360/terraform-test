import boto3
import os
import json
from mutagen.mp4 import MP4

def lambda_handler(event, context):
    s3 = boto3.client('s3', endpoint_url=os.environ.get('AWS_ENDPOINT_URL', None))
    bucket = os.environ['BUCKET_NAME']
    input_key = 'test_input.mp4'
    output_key = 'test_output.mp4'
    tmp_input = '/tmp/' + input_key
    tmp_output = '/tmp/' + output_key

    try:
        # Descargar el archivo de entrada
        s3.download_file(bucket, input_key, tmp_input)

        # Copiar archivo para modificación
        with open(tmp_input, 'rb') as f_in:
            with open(tmp_output, 'wb') as f_out:
                f_out.write(f_in.read())

        # Añadir metadatos usando mutagen
        videofile = MP4(tmp_output)
        
        # Añadir metadatos XMP como tags personalizados
        videofile.tags['----:com.smartsolutionslab360:Campo1'] = [b'Valor1']
        videofile.tags['----:com.smartsolutionslab360:Campo2'] = [b'Valor2']
        
        # Guardar los cambios
        videofile.save()

        # Subir el archivo modificado
        s3.upload_file(tmp_output, bucket, output_key)

        return {
            'statusCode': 200,
            'body': json.dumps(f'Archivo {output_key} generado con metadatos XMP')
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }